const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const dbPath = path.join(__dirname,'database.json');

function readDB(){
  if(!fs.existsSync(dbPath)){
    fs.writeFileSync(dbPath, JSON.stringify({users:[],tasks:[]}, null, 2), 'utf8');
  }
  const raw = fs.readFileSync(dbPath, 'utf8') || '{"users":[],"tasks":[]}';
  return JSON.parse(raw);
}

function writeDB(data){
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), 'utf8');
}

function hashPassword(password){
  return '{sha256}'+crypto.createHash('sha256').update(password).digest('hex');
}

function verifyPassword(password, stored){
  if(!stored) return false;
  if(stored.startsWith('{sha256}')){
    return stored === hashPassword(password);
  }
  return stored === password;
}

function genId(prefix){
  return prefix + '_' + crypto.randomBytes(6).toString('hex');
}

module.exports = { readDB, writeDB, hashPassword, verifyPassword, genId };
