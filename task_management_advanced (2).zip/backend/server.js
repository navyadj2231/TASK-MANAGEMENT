const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { readDB, writeDB, hashPassword, verifyPassword, genId } = require('./utils');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Middleware to read user role from header x-user (frontend will set role and username)
function getUserFromHeader(req){
  const header = req.headers['x-user'];
  try{ return header ? JSON.parse(header) : null; }catch(e){ return null; }
}

function ensureAdmin(req, res, next){
  const user = getUserFromHeader(req);
  if(!user || user.role !== 'admin') return res.status(403).json({ message:'Forbidden - Admins only' });
  req._user = user;
  next();
}

// Signup
app.post('/signup', (req,res)=>{
  const { username, password, role } = req.body;
  if(!username || !password) return res.status(400).json({ message: 'username and password required' });
  const db = readDB();
  if(db.users.find(u=>u.username === username)) return res.status(400).json({ message: 'user exists' });
  const id = genId('u');
  db.users.push({ id, username, password: hashPassword(password), role: role || 'user' });
  writeDB(db);
  res.json({ message: 'signup successful' });
});

// Login
app.post('/login', (req,res)=>{
  const { username, password } = req.body;
  const db = readDB();
  const user = db.users.find(u=>u.username === username);
  if(!user) return res.status(401).json({ message: 'invalid credentials' });
  if(!verifyPassword(password, user.password)) return res.status(401).json({ message: 'invalid credentials' });
  // return safe user object
  res.json({ user: { id: user.id, username: user.username, role: user.role } });
});

// Admin: manage users
app.get('/users', ensureAdmin, (req,res)=>{
  const db = readDB();
  res.json(db.users.map(u=>({ id:u.id, username:u.username, role:u.role })));
});

app.put('/users/:id', ensureAdmin, (req,res)=>{
  const db = readDB();
  const u = db.users.find(x=>x.id === req.params.id);
  if(!u) return res.status(404).json({ message: 'user not found' });
  const { username, role, password } = req.body;
  if(username) u.username = username;
  if(role) u.role = role;
  if(password) u.password = hashPassword(password);
  writeDB(db);
  res.json({ message: 'user updated' });
});

app.delete('/users/:id', ensureAdmin, (req,res)=>{
  const db = readDB();
  db.users = db.users.filter(x=>x.id !== req.params.id);
  writeDB(db);
  res.json({ message: 'deleted' });
});

// Tasks: create (admin)
app.post('/tasks', ensureAdmin, (req,res)=>{
  const { title, description, priority='low', status='open' } = req.body;
  if(!title) return res.status(400).json({ message: 'title required' });
  const db = readDB();
  const task = { id: genId('t'), title, description, priority, status, createdBy: req._user.username, createdAt: new Date().toISOString() };
  db.tasks.push(task);
  writeDB(db);
  res.json({ message: 'task created', task });
});

// Get tasks with search/filter/sort/pagination
app.get('/tasks', (req,res)=>{
  const db = readDB();
  let tasks = db.tasks.slice();

  const q = (req.query.q || '').toLowerCase();
  if(q) tasks = tasks.filter(t => (t.title||'').toLowerCase().includes(q) || (t.description||'').toLowerCase().includes(q));

  if(req.query.status) tasks = tasks.filter(t => t.status === req.query.status);
  if(req.query.priority) tasks = tasks.filter(t => t.priority === req.query.priority);

  const sortBy = req.query.sortBy;
  const sortDir = req.query.sortDir === 'desc' ? -1 : 1;
  if(sortBy){
    tasks.sort((a,b)=> (a[sortBy] > b[sortBy] ? 1 : -1) * sortDir);
  }

  // pagination
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.max(1, Math.min(50, Number(req.query.limit) || 10));
  const total = tasks.length;
  const start = (page-1)*limit;
  const paginated = tasks.slice(start, start+limit);

  res.json({ tasks: paginated, total });
});

// Update task (admin)
app.put('/tasks/:id', ensureAdmin, (req,res)=>{
  const db = readDB();
  const t = db.tasks.find(x=>x.id === req.params.id);
  if(!t) return res.status(404).json({ message: 'task not found' });
  const { title, description, priority, status } = req.body;
  if(title !== undefined) t.title = title;
  if(description !== undefined) t.description = description;
  if(priority !== undefined) t.priority = priority;
  if(status !== undefined) t.status = status;
  writeDB(db);
  res.json({ message: 'task updated', task: t });
});

// Delete task (admin)
app.delete('/tasks/:id', ensureAdmin, (req,res)=>{
  const db = readDB();
  db.tasks = db.tasks.filter(x=>x.id !== req.params.id);
  writeDB(db);
  res.json({ message: 'deleted' });
});

const PORT = 5000;
app.listen(PORT, ()=> console.log('Server running on http://localhost:'+PORT));
