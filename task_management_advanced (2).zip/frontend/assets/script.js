const API = 'http://localhost:5000';
function getUser(){ try{ return JSON.parse(localStorage.getItem('user')); }catch(e){return null} }
function setUser(u){ if(u) localStorage.setItem('user', JSON.stringify(u)); else localStorage.removeItem('user'); }
function authHeader(){ const u = getUser(); return u ? { 'X-User': JSON.stringify(u) } : {}; }
function goto(p){ location.href = p; }
function logout(){ setUser(null); location.href = 'login.html'; }

// Signup
async function signup(){
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const role = document.getElementById('role').value;
  if(!username||!password) return showMsg('msg','Enter username & password');
  const res = await fetch(API + '/signup',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ username, password, role }) });
  const data = await res.json();
  showMsg('msg', data.message || 'Done');
  if(res.ok) setTimeout(()=> location.href = 'login.html', 700);
}

// Login
async function login(){
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  if(!username||!password) return showMsg('msg','Enter username & password');
  const res = await fetch(API + '/login',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ username, password }) });
  const data = await res.json();
  if(!res.ok){ showMsg('msg', data.message || 'Login failed'); return; }
  setUser(data.user); location.href = 'dashboard.html';
}

function showMsg(id, msg){ const el = document.getElementById(id); if(el) el.textContent = msg; }

// Init page behaviors
(function init(){
  const path = location.pathname.split('/').pop();
  const user = getUser();
  if(path === 'dashboard.html'){
    if(!user) return location.href = 'login.html';
    document.getElementById('userInfo').textContent = `${user.username} (${user.role})`;
    if(user.role === 'admin') document.getElementById('manageUsersBtn').style.display = 'inline-block';
  }
  if(path === 'tasks.html'){
    if(!user) return location.href = 'login.html';
    if(user.role === 'admin') renderAddForm();
    loadTasks();
  }
  if(path === 'admin-users.html'){
    if(!user) return location.href = 'login.html';
    if(user.role !== 'admin') return alert('Admins only');
    loadUsers();
  }
})();

// Admin add task form
function renderAddForm(){
  const panel = document.getElementById('adminPanel');
  panel.innerHTML = `<div class="card">
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <input id="title" placeholder="Title">
      <input id="description" placeholder="Description">
      <select id="prioritySelect"><option value="low">low</option><option value="medium">medium</option><option value="high">high</option></select>
      <select id="statusSelect"><option value="open">open</option><option value="in-progress">in-progress</option><option value="done">done</option></select>
      <button onclick="createTask()">Create</button>
    </div></div>`;
}

// Create task
async function createTask(){
  const title = document.getElementById('title').value.trim();
  const description = document.getElementById('description').value.trim();
  const priority = document.getElementById('prioritySelect').value;
  const status = document.getElementById('statusSelect').value;
  if(!title) return alert('Title required');
  const headers = Object.assign({'Content-Type':'application/json'}, authHeader());
  await fetch(API + '/tasks', { method:'POST', headers, body: JSON.stringify({ title, description, priority, status }) });
  loadTasks();
}

// Load tasks with query params
let currentPage = 1; const pageSize = 6; let lastTotal = 0;
async function loadTasks(page=1){
  currentPage = page;
  const q = document.getElementById('q') ? document.getElementById('q').value.trim() : '';
  const status = document.getElementById('statusFilter') ? document.getElementById('statusFilter').value : '';
  const priority = document.getElementById('priorityFilter') ? document.getElementById('priorityFilter').value : '';
  const sortBy = document.getElementById('sortBy') ? document.getElementById('sortBy').value : '';
  const sortDir = document.getElementById('sortDir') ? document.getElementById('sortDir').value : 'asc';
  const params = new URLSearchParams();
  if(q) params.set('q', q);
  if(status) params.set('status', status);
  if(priority) params.set('priority', priority);
  if(sortBy) params.set('sortBy', sortBy);
  if(sortDir) params.set('sortDir', sortDir);
  params.set('page', page);
  params.set('limit', pageSize);
  const res = await fetch(API + '/tasks?' + params.toString());
  const data = await res.json();
  const tasks = data.tasks || [];
  lastTotal = data.total || 0;
  renderTasks(tasks);
  renderPager();
}

function renderTasks(tasks){
  const user = getUser();
  let html = '<tr><th>Title</th><th>Description</th><th>Priority</th><th>Status</th><th>Created</th>' + (user && user.role==='admin' ? '<th>Actions</th>' : '') + '</tr>';
  tasks.forEach(t=>{
    html += `<tr>
      <td>${escapeHtml(t.title)}</td>
      <td>${escapeHtml(t.description||'')}</td>
      <td>${t.priority}</td>
      <td>${t.status}</td>
      <td class="small">${new Date(t.createdAt).toLocaleString()}</td>`;
    if(user && user.role==='admin'){
      html += `<td class="actions"><button class="action-btn edit-btn" onclick="openEdit('${t.id}')">Edit</button><button class="action-btn delete-btn" onclick="deleteTask('${t.id}')">Delete</button></td>`;
    }
    html += '</tr>';
  });
  document.getElementById('taskTable').innerHTML = html;
}

function renderPager(){
  const totalPages = Math.max(1, Math.ceil(lastTotal / pageSize));
  let html = '';
  if(currentPage>1) html += `<button class="ghost" onclick="loadTasks(${currentPage-1})">Prev</button>`;
  html += `<span class="small" style="margin:0 8px">Page ${currentPage} / ${totalPages}</span>`;
  if(currentPage<totalPages) html += `<button class="ghost" onclick="loadTasks(${currentPage+1})">Next</button>`;
  document.getElementById('pager').innerHTML = html;
}

// Edit task
async function openEdit(id){
  const res = await fetch(API + '/tasks');
  const all = await res.json();
  const t = all.tasks.find(x=>x.id===id) || all.find?.(x=>x.id===id);
  const title = prompt('Title', t.title);
  if(title===null) return;
  const description = prompt('Description', t.description||'');
  const priority = prompt('Priority (low|medium|high)', t.priority||'low');
  const status = prompt('Status (open|in-progress|done)', t.status||'open');
  await fetch(API + '/tasks/' + id, { method:'PUT', headers: Object.assign({'Content-Type':'application/json'}, authHeader()), body: JSON.stringify({ title, description, priority, status }) });
  loadTasks(currentPage);
}

// Delete task
async function deleteTask(id){
  if(!confirm('Delete task?')) return;
  await fetch(API + '/tasks/' + id, { method:'DELETE', headers: authHeader() });
  loadTasks(currentPage);
}

// Users admin page
async function loadUsers(){
  const res = await fetch(API + '/users', { headers: authHeader() });
  const users = await res.json();
  let html = '<table class="table"><tr><th>Id</th><th>Username</th><th>Role</th><th>Actions</th></tr>';
  users.forEach(u=>{
    html += `<tr><td>${u.id}</td><td>${u.username}</td><td>${u.role}</td><td><button class="ghost" onclick="editUser('${u.id}')">Edit</button><button class="delete-btn" onclick="deleteUser('${u.id}')">Delete</button></td></tr>`;
  });
  html += '</table>';
  document.getElementById('usersArea').innerHTML = html;
}

async function editUser(id){
  const username = prompt('New username');
  const role = prompt('Role (admin/user)');
  if(!username||!role) return;
  await fetch(API + '/users/' + id, { method:'PUT', headers: Object.assign({'Content-Type':'application/json'}, authHeader()), body: JSON.stringify({ username, role }) });
  loadUsers();
}

async function deleteUser(id){
  if(!confirm('Delete user?')) return;
  await fetch(API + '/users/' + id, { method:'DELETE', headers: authHeader() });
  loadUsers();
}

function escapeHtml(unsafe){ if(!unsafe) return ''; return unsafe.replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#039;"}[c]; }); }
